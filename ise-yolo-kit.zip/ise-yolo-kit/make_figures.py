"""
Build the ISE vs YOLOv8 early-warning figures from the six CSVs in ./data
(works on the synthetic practice data now, and on your real data later - same column names).

Usage:  python make_figures.py              -> writes ./figures/*.png and ./figures/alarm_table.csv

Set the alarm rules below before you look at results, and report them in your methods.
"""
import numpy as np, pandas as pd, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from pathlib import Path

HERE = Path(__file__).parent
DATA, FIG = HERE / "data", HERE / "figures"; FIG.mkdir(exist_ok=True)

# ------------------------- ALARM RULES (decide these in advance) -------------------------
TARGET = {"NO3": 12.0, "K": 6.0}   # full-strength solution, mM
ISE_FRAC = 0.70                    # ISE alarm: 24-h rolling median below 70 % of target
YOLO_CONF = 0.50                   # YOLO alarm: >= YOLO_MIN_PLANTS plants with a stress class at conf >= this
YOLO_MIN_PLANTS = 2
ONSET_MIN_PLANTS = 2               # visible onset: >= this many plants with blinded score >= 1
TISSUE_LOW = {"N": 2.0, "K": 1.5}  # % dry weight; set to the sufficiency limits you cite
ION_FOR = {"minus_N": "NO3", "minus_K": "K"}   # which ion is the relevant one per treatment
# ----------------------------------------------------------------------------------------

ISE_C, YOLO_C, FUSE_C, GREY = "#2a78d6", "#eb6834", "#1baf7a", "#a3a29c"
INK, INK2, GRID, SURF = "#0b0b0b", "#52514e", "#e6e5e0", "#fcfcfb"
plt.rcParams.update({"font.family": ["Inter", "DejaVu Sans"], "font.size": 9, "axes.spines.top": False,
    "axes.spines.right": False, "axes.edgecolor": "#c9c8c2", "figure.facecolor": SURF, "axes.facecolor": SURF,
    "axes.grid": True, "grid.color": GRID, "axes.titlelocation": "left", "axes.titleweight": "bold",
    "legend.frameon": False, "lines.linewidth": 2, "xtick.color": INK2, "ytick.color": INK2, "axes.labelcolor": INK2})

units = pd.read_csv(DATA / "1_units_and_plants.csv")
ise = pd.read_csv(DATA / "2_ise_readings.csv", parse_dates=["timestamp"])
det = pd.read_csv(DATA / "4_yolo_detections.csv", parse_dates=["timestamp"])
ref = pd.read_csv(DATA / "5_reference_truth.csv", parse_dates=["date"])
ev = pd.read_csv(DATA / "6_events_log.csv", parse_dates=["timestamp"])
synthetic = "synthetic" in det.columns and (det["synthetic"] == "yes").any()
NOTE = "SYNTHETIC PRACTICE DATA - not experimental results" if synthetic else ""
t0 = ev.loc[ev.event == "solution_change", "timestamp"].min()
day = lambda ts: (ts - t0).dt.total_seconds() / 86400

res_treat = units.groupby("reservoir_id").treatment.first()
ise["d"] = day(ise.timestamp); det["d"] = day(det.timestamp); ref["d"] = day(ref.date)
ise["pct"] = ise.apply(lambda r: 100 * r.conc_mM / TARGET[r.ion], axis=1)
ise = ise.sort_values(["reservoir_id", "ion", "timestamp"]).reset_index(drop=True)
ise["pct_roll"] = np.concatenate([g.set_index("timestamp").pct.rolling("24h").median().to_numpy()
                                  for _, g in ise.groupby(["reservoir_id", "ion"], sort=False)])
det["stress"] = np.where(det["class"] != "healthy", det.confidence, 1 - det.confidence)

def first(s): return s.min() if len(s) else np.nan
rows = []
for rid, tr in res_treat.items():
    a = ise[(ise.reservoir_id == rid) & (ise.pct_roll < ISE_FRAC * 100)]
    ise_alarm = first(a.d)
    hits = det[(det.reservoir_id == rid) & (det["class"] != "healthy") & (det.confidence >= YOLO_CONF)]
    per_day = hits.groupby(hits.d.round()).plant_id.nunique()
    yolo_alarm = first(per_day[per_day >= YOLO_MIN_PLANTS].index.to_series())
    sc = ref[(ref.reservoir_id == rid) & (ref.visible_symptom_score_0to4 >= 1)].groupby("d").plant_id.nunique()
    onset = first(sc[sc >= ONSET_MIN_PLANTS].index.to_series())
    nut = {"minus_N": "N", "minus_K": "K"}.get(tr)
    tissue = first(ref[(ref.reservoir_id == rid) & (ref[f"tissue_{nut}_pct"] < TISSUE_LOW[nut])].d) if nut else np.nan
    rows.append(dict(reservoir_id=rid, treatment=tr, ise_alarm_day=ise_alarm, yolo_alarm_day=yolo_alarm,
                     either_alarm_day=np.nanmin([ise_alarm, yolo_alarm]) if not (np.isnan(ise_alarm) and np.isnan(yolo_alarm)) else np.nan,
                     both_alarm_day=np.nanmax([ise_alarm, yolo_alarm]) if not (np.isnan(ise_alarm) or np.isnan(yolo_alarm)) else np.nan,
                     tissue_low_day=tissue, visible_onset_day=onset))
al = pd.DataFrame(rows)
for m in ["ise", "yolo", "either", "both"]:
    al[f"{m}_lead_days"] = al.visible_onset_day - al[f"{m}_alarm_day"]
al.round(2).to_csv(FIG / "alarm_table.csv", index=False)
stressed = al[al.treatment != "control"].copy()

def header(fig, title, sub):
    fig.text(0.015, 0.975, title, fontsize=14, weight="bold", color=INK, va="top")
    fig.text(0.015, 0.93, sub, fontsize=9.5, color=INK2, va="top")
    if NOTE: fig.text(0.985, 0.975, NOTE, fontsize=8, color="#e34948", ha="right", va="top", weight="semibold")

# ============ Figure 1: who raises the alarm first ============
s = stressed.sort_values("ise_lead_days", na_position="last").reset_index(drop=True)
fig = plt.figure(figsize=(13, 7.5))
header(fig, "Who raises the alarm first?", f"ISE: 24-h median < {ISE_FRAC:.0%} of target · YOLOv8: ≥{YOLO_MIN_PLANTS} plants at conf ≥ {YOLO_CONF} · onset: ≥{ONSET_MIN_PLANTS} plants with blinded score ≥ 1")
gs = fig.add_gridspec(2, 2, width_ratios=[1.5, 1], left=0.08, right=0.98, top=0.8, bottom=0.08, hspace=0.5, wspace=0.2)
ax = fig.add_subplot(gs[:, 0])
for r, row in s.iterrows():
    ax.plot([0, row.visible_onset_day], [r, r], color=GRID, lw=2)
    if not np.isnan(row.either_alarm_day):
        ax.plot([row.either_alarm_day, row.visible_onset_day], [r, r], color="#bcd4f2", lw=6, solid_capstyle="round")
    if not np.isnan(row.ise_alarm_day): ax.scatter(row.ise_alarm_day, r, s=46, color=ISE_C, ec=SURF, zorder=4)
    else: ax.text(row.visible_onset_day + 0.6, r, "no ISE alarm", fontsize=7.5, va="center", color=INK2)
    if not np.isnan(row.yolo_alarm_day): ax.scatter(row.yolo_alarm_day, r, s=50, marker="D", color=YOLO_C, ec=SURF, zorder=4)
    if not np.isnan(row.tissue_low_day): ax.scatter(row.tissue_low_day, r, s=60, marker="|", color=INK, lw=1.6, zorder=3)
    ax.scatter(row.visible_onset_day, r, s=40, marker="x", color=INK, lw=1.6, zorder=3)
ax.set_yticks(range(len(s))); ax.set_yticklabels([f"{a} · {b}" for a, b in zip(s.reservoir_id, s.treatment)], fontsize=8)
ax.grid(axis="y", visible=False); ax.set_xlabel("Days since solution change"); ax.set_xlim(0, None)
ax.set_title("Timeline per reservoir (shaded = warning window)", pad=40)
h = [ax.scatter([], [], s=46, color=ISE_C, label="ISE alarm"), ax.scatter([], [], s=46, marker="D", color=YOLO_C, label="YOLOv8 alarm"),
     ax.scatter([], [], s=60, marker="|", color=INK, label="Tissue below sufficiency"), ax.scatter([], [], s=40, marker="x", color=INK, label="Visible onset")]
ax.legend(handles=h, loc="lower left", bbox_to_anchor=(0, 1.0), ncol=4, fontsize=8)
ax2 = fig.add_subplot(gs[0, 1])
dd = (s.yolo_alarm_day - s.ise_alarm_day).dropna()
if len(dd):
    b = np.arange(np.floor(dd.min()) - 1, np.ceil(dd.max()) + 2)
    cnt, _ = np.histogram(dd, b)
    ax2.bar(b[:-1] + 0.5, cnt, width=0.86, color=[YOLO_C if x < 0 else ISE_C for x in b[:-1]], edgecolor=SURF)
    ax2.axvline(0, color=INK2, lw=1); ax2.axvline(dd.median(), color=INK, ls="--", lw=1)
    ax2.set_title(f"ISE first in {(dd > 0).sum()} of {len(dd)} (median {dd.median():.1f} d ahead)")
ax2.set_xlabel("YOLOv8 alarm day − ISE alarm day"); ax2.set_ylabel("Reservoirs"); ax2.grid(axis="x", visible=False)
ax3 = fig.add_subplot(gs[1, 1]); rel = np.linspace(-14, 4, 181)
for m, c, lab in [("ise", ISE_C, "ISE"), ("yolo", YOLO_C, "YOLOv8"), ("either", FUSE_C, "Either alarms")]:
    x = s[f"{m}_alarm_day"] - s.visible_onset_day
    ax3.step(rel, [(x <= v).mean() * 100 for v in rel], where="post", color=c, label=lab)
ax3.axvline(0, color=INK2, lw=1); ax3.set_ylim(0, 105); ax3.legend(fontsize=8, loc="upper left")
ax3.set_xlabel("Days relative to visible onset"); ax3.set_ylabel("Stressed reservoirs alarmed (%)")
ax3.set_title("Cumulative detection")
fig.savefig(FIG / "fig1_race_to_detect.png", dpi=200); plt.close(fig)

# ============ Figure 2: phase portrait + lag ============
grp = {"control": ("Control", GREY), "minus_N": ("−N", ISE_C), "minus_K": ("−K", "#6250d6"), "mildew": ("Powdery mildew", YOLO_C)}
fig = plt.figure(figsize=(13, 6.3))
header(fig, "Two sensors, two directions of travel", "Daily reservoir means: relevant ion by ISE (x) vs YOLOv8 stress score (y); dots every 5 days")
gs = fig.add_gridspec(1, 2, width_ratios=[1.3, 1], left=0.07, right=0.98, top=0.82, bottom=0.11, wspace=0.22)
ax = fig.add_subplot(gs[0]); ax2 = fig.add_subplot(gs[1]); lags = np.arange(-8, 9)
for tr, (lab, c) in grp.items():
    ion = ION_FOR.get(tr, "NO3"); cc_all = []
    for rid in res_treat[res_treat == tr].index:
        x = ise[(ise.reservoir_id == rid) & (ise.ion == ion)].groupby(np.floor(ise.d)).pct.mean()
        y = det[det.reservoir_id == rid].groupby(np.floor(det.d)).stress.mean()
        j = pd.concat([x, y], axis=1, keys=["x", "y"]).dropna()
        ax.plot(j.x, j.y, color=c, lw=0.8, alpha=0.4)
        ax.scatter(j.x.iloc[::5], j.y.iloc[::5], s=14, color=c, zorder=3)
        dx, dy = -j.x.rolling(3, center=True).mean().diff(), j.y.rolling(3, center=True).mean().diff()
        cc_all.append([dx.corr(dy.shift(-L)) for L in lags])
    ax.plot([], [], color=c, label=lab)
    if tr != "control": ax2.plot(lags, np.nanmean(cc_all, 0), color=c, marker="o", ms=4, label=lab)
ax.axvline(ISE_FRAC * 100, color=ISE_C, ls="--", lw=1); ax.axhline(YOLO_CONF, color=YOLO_C, ls="--", lw=1)
ax.set_xlabel("Relevant ion by ISE (% of target)  ← falling supply"); ax.set_ylabel("YOLOv8 stress score (mean over plants)")
ax.legend(loc="center left", fontsize=8.5); ax.set_title("Trajectories, one line per reservoir")
ax2.axhline(0, color=INK2, lw=0.8); ax2.axvline(0, color=INK2, lw=0.8)
ax2.set_xlabel("Lag (days) — positive = ISE change leads YOLOv8 change"); ax2.set_ylabel("Cross-correlation of daily changes")
ax2.legend(fontsize=8.5, loc="upper left"); ax2.set_title("How far ahead does the ISE signal run?")
fig.savefig(FIG / "fig2_phase_portrait_and_lag.png", dpi=200); plt.close(fig)

# ============ Figure 3: lead time by condition + ISE threshold trade-off ============
fig = plt.figure(figsize=(13, 5.8))
header(fig, "Where each sensor wins, and what earlier warning costs", "Each dot is one reservoir. False alarms = alarms in reservoirs without that nutrient stress (controls + mildew).")
gs = fig.add_gridspec(1, 2, width_ratios=[1.3, 1], left=0.1, right=0.98, top=0.8, bottom=0.12, wspace=0.25)
ax = fig.add_subplot(gs[0]); trs = ["minus_N", "minus_K", "mildew"]
for k, (m, c, off) in enumerate([("ise", ISE_C, -0.22), ("yolo", YOLO_C, 0), ("either", FUSE_C, 0.22)]):
    for i, tr in enumerate(trs):
        v = stressed.loc[stressed.treatment == tr, f"{m}_lead_days"]
        ax.scatter(v.dropna(), np.full(v.notna().sum(), i + off), s=30, color=c, ec=SURF, zorder=3, label={"ise": "ISE", "yolo": "YOLOv8", "either": "Either"}[m] if i == 0 else None)
        if v.notna().any(): ax.plot([v.median()] * 2, [i + off - 0.09, i + off + 0.09], color=INK, lw=1.5)
        if v.isna().all(): ax.text(0.2, i + off, "no alarm", fontsize=7.5, va="center", color=c)
ax.axvline(0, color=INK2, lw=1); ax.set_yticks(range(len(trs))); ax.set_yticklabels([grp[t][0] for t in trs]); ax.invert_yaxis()
ax.grid(axis="y", visible=False); ax.legend(fontsize=8.5, loc="lower right"); ax.set_xlabel("Warning before visible onset (days); black tick = median")
ax.set_title("Lead time by condition")
ax2 = fig.add_subplot(gs[1]); fr = np.arange(0.40, 0.96, 0.05); leads, fas = [], []
for f in fr:
    lead, fa = [], 0
    for rid, tr in res_treat.items():
        ion = ION_FOR.get(tr)
        for io in TARGET:
            a = ise[(ise.reservoir_id == rid) & (ise.ion == io) & (ise.pct_roll < f * 100)].d
            if ion == io:
                on = al.set_index("reservoir_id").visible_onset_day[rid]; lead.append(on - a.min() if len(a) else np.nan)
            elif len(a): fa += 1
    leads.append(np.nanmedian(lead)); fas.append(fa)
ax2.plot(fr * 100, leads, color=ISE_C, marker="o", ms=4)
for f, l, n in zip(fr, leads, fas):
    if n: ax2.text(f * 100, l + 0.4, f"{n} FA", fontsize=7, ha="center", color="#e34948")
ax2.axvline(ISE_FRAC * 100, color=INK2, ls="--", lw=1)
ax2.set_xlabel("ISE alarm threshold (% of target)"); ax2.set_ylabel("Median ISE lead time, −N and −K (days)")
ax2.set_title("Raising the ISE threshold: earlier, until false alarms (FA) appear")
fig.savefig(FIG / "fig3_lead_time_and_threshold.png", dpi=200); plt.close(fig)

print(al.round(1).to_string(index=False))
print("\nFigures written to", FIG)
